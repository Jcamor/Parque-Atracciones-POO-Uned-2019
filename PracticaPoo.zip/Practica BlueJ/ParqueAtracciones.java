
/**
 * Write a description of class ParqueAtracciones here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
//import java.util.InputMismatchException;
//import java.util.Scanner;
 
public class ParqueAtracciones
{
        
    public static void main(String[] args) 
    {
        Menu menu = new Menu();
        menu.menuPrincipal();
    }
}   