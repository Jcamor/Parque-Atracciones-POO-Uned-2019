
/**
 * Write a description of class Senior here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Senior extends Cliente {

	public Senior(String dni, String nombre, int edad, int alturaCm, String fechaEntrada, boolean diversidadFuncional) {
		super(dni, nombre, edad, alturaCm, fechaEntrada, diversidadFuncional);
		// TODO Auto-generated constructor stub
	}

	
}
